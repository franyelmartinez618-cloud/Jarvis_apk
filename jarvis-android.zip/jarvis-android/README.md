# Jarvis — asistente de voz personal para Android (versión 1)

App de uso personal, 100 % gratis y sin cuentas ni claves. Se activa con
**"Jarvis activate"**, te responde con voz y puede:

- Llamar: "llama a mamá", "llama al 555 1234"
- WhatsApp: "manda un WhatsApp a Juan diciendo que llego tarde" (abre el chat con el mensaje listo; **tú tocas enviar**)
- SMS: "manda un SMS a Ana diciendo hola" (se envía solo, después de confirmarlo por voz)
- Abrir apps: "abre Spotify"
- "qué hora es", "qué día es hoy"

Si hay varios contactos parecidos te pregunta cuál. Si una llamada se corta enseguida
(sin saldo, ocupado, apagado) te lo avisa por voz.

---

## Cómo sacar el APK (sin instalar nada en la PC)

1. Crea una cuenta gratis en https://github.com
2. Crea un repositorio nuevo (botón **New**), ponle de nombre `jarvis`, déjalo **Private** y créalo.
3. En el repositorio: **Add file → Upload files**. Descomprime este .zip y arrastra **todo el contenido**
   (carpeta `app`, archivos `build.gradle.kts`, `settings.gradle.kts`, etc., y la carpeta oculta `.github`).
   Pulsa **Commit changes**.
   - Si la carpeta oculta `.github` no se subió: **Add file → Create new file**, escribe como nombre
     `.github/workflows/build-apk.yml` y pega el contenido del archivo con ese mismo nombre.
4. Ve a la pestaña **Actions**. Verás "Compilar APK de Jarvis" ejecutándose (tarda unos 5-10 minutos).
   Si no arrancó sola: entra al workflow y pulsa **Run workflow**.
5. Cuando tenga el tilde verde, entra a esa ejecución y abajo, en **Artifacts**, descarga **jarvis-apk**.
   Es un .zip: ábrelo y dentro está `app-debug.apk`.
6. Pasa el APK al celular e instálalo (acepta "Instalar apps desconocidas"; si sale
   Play Protect, toca **Instalar de todos modos**).

## Primer uso en el Redmi Note 13

Abre la app Jarvis y toca los botones **en orden**:

1. **Dar permisos** → permite todo (micrófono, llamadas, estado del teléfono, contactos, SMS, notificaciones).
2. **Mostrar sobre otras apps** → activa Jarvis. (Sin esto Android no deja abrir WhatsApp ni otras apps desde segundo plano.)
3. **Quitar restricción de batería** → Permitir.
4. **Permisos extra de Xiaomi** → en la lista busca **"Mostrar ventanas emergentes mientras se ejecuta en segundo plano"**
   (o similar) y actívalo. Si el botón no abre esa pantalla, ve a Ajustes → Aplicaciones → Permisos → Jarvis → Otros permisos.
5. **Inicio automático** → activa Jarvis.
6. Escribe tu **código de país** (ej. 54 Argentina) y guarda. Se usa para WhatsApp con contactos sin "+código".
7. Toca **INICIAR JARVIS**. La primera vez tarda unos segundos en preparar el modelo de voz.

Después puedes cerrar la app: queda una notificación fija "Escuchando". Di **"Jarvis activate"**, espera
el "Dime" y da la orden.

Consejo extra en Xiaomi: en Recientes, mantén pulsada la tarjeta de Jarvis y ponle el **candado**
para que no la cierre.

## Si algo falla

- **No responde a "Jarvis activate"**: habla claro y cerca, pronuncia "yárvis activéit". Revisa que la notificación diga "Escuchando".
- **Dice que falta el modelo**: el APK se compiló sin el modelo; vuelve a ejecutar el workflow y revisa que el paso "Descargar el modelo de voz" esté en verde.
- **No me escucha después del "Dime"**: necesita la app de Google (reconocimiento de voz) activa y con idioma español.
- **No abre WhatsApp**: revisa los pasos 2 y 4.
- Si el workflow de GitHub muestra un error rojo, copia el texto del error y envíamelo para corregirlo.

## Estructura

- `Parser.kt` — entiende las órdenes (reglas propias, sin internet)
- `Contacts.kt` — busca contactos
- `WakeWordListener.kt` — escucha "jarvis activate" con Vosk (offline)
- `JarvisService.kt` — servicio en segundo plano: voz, llamadas, SMS, WhatsApp, apps
- `MainActivity.kt` — pantalla de permisos y botones

## Próximas fases

IA gratuita para conversar y responder preguntas generales, consulta de saldo (USSD),
envío automático de WhatsApp y más herramientas.
