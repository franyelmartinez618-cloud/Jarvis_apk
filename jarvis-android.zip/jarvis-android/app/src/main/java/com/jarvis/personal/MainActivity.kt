package com.jarvis.personal

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Pantalla única: permisos, ajustes y botón Iniciar/Detener. Toda la interfaz se arma por código. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var countryInput: EditText

    private val runtimePermissions: Array<String>
        get() {
            val list = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.SEND_SMS
            )
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            return list.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "JARVIS"
            textSize = 30f
            setTextColor(Color.parseColor("#00A3B8"))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Asistente de voz personal. Di “Jarvis activate”."
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        })

        status = TextView(this).apply { textSize = 15f; setPadding(0, 0, 0, pad) }
        root.addView(status)

        root.addView(button("1. Dar permisos (micrófono, llamadas, contactos, SMS)") {
            requestPermissions(runtimePermissions, 100)
        })
        root.addView(button("2. Permitir “Mostrar sobre otras apps”") {
            openSafely(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("3. Quitar restricción de batería") {
            openSafely(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        })
        root.addView(button("4. Permisos extra de Xiaomi") { openXiaomiPermissions() })
        root.addView(button("5. Inicio automático (Xiaomi)") { openXiaomiAutostart() })

        root.addView(TextView(this).apply {
            text = "\nCódigo de país para WhatsApp (ej. 54 Argentina, 52 México, 57 Colombia). " +
                "Sirve para contactos guardados sin el +código:"
        })
        countryInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "54"
            setText(prefs().getString(JarvisService.PREF_COUNTRY, ""))
        }
        root.addView(countryInput)
        root.addView(button("Guardar código de país") {
            prefs().edit()
                .putString(JarvisService.PREF_COUNTRY, countryInput.text.toString().trim())
                .apply()
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
        })

        root.addView(button("▶  INICIAR JARVIS") { startJarvis() }.apply {
            setBackgroundColor(Color.parseColor("#00E5FF"))
        })
        root.addView(button("■  DETENER JARVIS") {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            refresh()
        })

        root.addView(TextView(this).apply {
            text = "\nÓrdenes que entiende:\n" +
                "• llama a mamá / llama al 555 1234\n" +
                "• manda un WhatsApp a Juan diciendo que llego tarde\n" +
                "• manda un SMS a Ana diciendo hola\n" +
                "• abre Spotify\n" +
                "• qué hora es / qué día es hoy"
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun prefs() = getSharedPreferences(JarvisService.PREFS, Context.MODE_PRIVATE)

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        val allPerms = runtimePermissions.all { granted(it) }
        val overlay = Settings.canDrawOverlays(this)
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = "${mark(allPerms)} Permisos básicos\n" +
            "${mark(overlay)} Mostrar sobre otras apps\n" +
            "${mark(battery)} Sin restricción de batería\n\n" +
            if (JarvisService.running) "🟢 Jarvis está ESCUCHANDO" else "⚪ Jarvis está detenido"
    }

    private fun startJarvis() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Primero da los permisos (botón 1)", Toast.LENGTH_LONG).show()
            requestPermissions(runtimePermissions, 100)
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Cargando… la primera vez tarda unos segundos", Toast.LENGTH_LONG).show()
        status.postDelayed({ refresh() }, 1500)
    }

    private fun openSafely(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            openAppDetails()
        }
    }

    private fun openAppDetails() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            Toast.makeText(this, "No pude abrir los ajustes", Toast.LENGTH_SHORT).show()
        }
    }

    /** Pantalla de permisos de MIUI/HyperOS (ahí está “Mostrar ventanas emergentes en segundo plano”). */
    private fun openXiaomiPermissions() {
        try {
            val i = Intent("miui.intent.action.APP_PERM_EDITOR")
                .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                .putExtra("extra_pkgname", packageName)
            startActivity(i)
        } catch (_: Exception) {
            openAppDetails()
        }
    }

    private fun openXiaomiAutostart() {
        try {
            startActivity(
                Intent().setComponent(
                    ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                )
            )
        } catch (_: Exception) {
            openAppDetails()
        }
    }
}
