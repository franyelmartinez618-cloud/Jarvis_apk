package com.jarvis.personal

import android.content.Context
import android.provider.ContactsContract

/** Una persona + número posible de llamar o escribir. */
data class Candidate(val name: String, val typeLabel: String, val number: String) {
    val label: String get() = if (typeLabel.isBlank()) name else "$name, $typeLabel"
}

object Contacts {

    /** Si lo dictado parece un número de teléfono (al menos 6 dígitos), lo devuelve limpio. */
    fun asNumber(target: String): String? {
        val digits = target.filter { it.isDigit() }
        if (digits.length < 6) return null
        // Solo es número si el texto casi no tiene letras
        val letters = target.count { it.isLetter() }
        if (letters > 2) return null
        return if (target.trim().startsWith("+")) "+$digits" else digits
    }

    /** Busca en los contactos por nombre (sin importar acentos ni mayúsculas). */
    fun find(context: Context, query: String): List<Candidate> {
        val q = strip(query).trim()
        if (q.isEmpty()) return emptyList()
        val tokens = q.split(Regex("\\s+")).filter { it.isNotEmpty() }

        val found = mutableListOf<Candidate>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL
        )
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        ) ?: return emptyList()

        cursor.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val type = c.getInt(2)
                val custom = c.getString(3)
                val n = strip(name)
                if (tokens.all { n.contains(it) }) {
                    val label = ContactsContract.CommonDataKinds.Phone
                        .getTypeLabel(context.resources, type, custom).toString()
                    found.add(Candidate(name, label, number))
                }
            }
        }

        // Sin duplicados (mismo número)
        val unique = found.distinctBy { it.number.filter { ch -> ch.isDigit() }.takeLast(8) }

        // Si hay coincidencia exacta de nombre, solo esas
        val exact = unique.filter { strip(it.name).trim() == q }
        return if (exact.isNotEmpty()) exact else unique
    }
}
