package com.jarvis.personal

import java.text.Normalizer
import java.util.Locale

enum class Via { WHATSAPP, SMS }

sealed class Cmd {
    data class Call(val target: String) : Cmd()
    data class Message(val via: Via, val target: String, val body: String?) : Cmd()
    data class OpenApp(val name: String) : Cmd()
    object Time : Cmd()
    object DateToday : Cmd()
    object Cancel : Cmd()
    data class Unknown(val raw: String) : Cmd()
}

/** Quita acentos y pasa a minúsculas (conserva el largo del texto). */
fun strip(s: String): String {
    val marks = Regex("\\p{InCombiningDiacriticalMarks}+")
    return marks.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "").lowercase(Locale.ROOT)
}

/** Interpreta órdenes en español con reglas propias (sin internet, sin costo). */
object Parser {
    private const val P = "\\s*(?:(?:jarvis|por favor|podrias|puedes|quiero que|necesito que)\\s+)*"
    private const val KIND = "(?:whatsapp|wasap|guasap|watsap|whatsap|wsp|sms|mensaje(?: de texto)?)"
    private const val CONNECT =
        "(?:diciendole que|diciendo que|diciendole|diciendo|que diga|que dice|dile que|y dile que|y dile|con el mensaje|con el texto|que)"

    private val WA = Regex("\\b(?:whatsapp|wasap|guasap|watsap|whatsap|wsp)\\b")
    private val SMS = Regex("\\b(?:sms|mensaje de texto)\\b")
    private val MSG_VERB = Regex("^${P}(?:manda|mandale|envia|enviale|escribe|escribile|escribi)\\b")
    private val MSG_FULL = Regex("\\b(?:a|al|para)\\s+(.+?)\\s+$CONNECT\\s+(.+)$")
    private val MSG_TARGET = Regex("\\b(?:a|al|para)\\s+(.+)$")
    private val KIND_TAIL = Regex("\\s+(?:por\\s+)?(?:un\\s+)?$KIND$")
    private val CALL = Regex("^${P}(?:llama|llamame|llamar|llamale|marca|marcar|telefonea|comunicame con)\\s+(?:a la\\s+|a\\s+|al\\s+)?(.+)$")
    private val OPEN = Regex("^${P}(?:abre|abri|abrir|inicia|ejecuta|lanza)\\s+(?:la\\s+|el\\s+)?(?:app\\s+|aplicacion\\s+)?(?:de\\s+)?(.+)$")
    private val TIME = Regex("\\bque hora\\b|\\bla hora\\b")
    private val DATE = Regex("\\bque dia\\b|\\bque fecha\\b|\\bfecha de hoy\\b")
    private val CANCEL = Regex("^(?:cancela|cancelar|olvidalo|olvida|no importa|nada|deja|dejalo|para)$")

    fun cleanTarget(t: String): String =
        t.trim().replace(KIND_TAIL, "").replace(Regex("^(?:mi|mis|el|la)\\s+"), "").trim()

    fun parse(raw: String): Cmd {
        val text = raw
        // Se reemplaza la puntuación por espacios para conservar las posiciones del texto original
        val s = strip(text).replace(Regex("[¿?¡!.,:;]"), " ")
        val st = s.trim()
        if (st.isEmpty()) return Cmd.Unknown(raw)

        if (MSG_VERB.containsMatchIn(s)) {
            val via = if (SMS.containsMatchIn(s) && !WA.containsMatchIn(s)) Via.SMS else Via.WHATSAPP
            val full = MSG_FULL.find(s)
            if (full != null) {
                val target = cleanTarget(full.groupValues[1])
                val r = full.groups[2]!!.range
                // El texto del mensaje se toma del original (con mayúsculas y acentos)
                val body = if (text.length == s.length) {
                    text.substring(r.first, r.last + 1)
                } else {
                    full.groupValues[2]
                }
                return Cmd.Message(via, target, body.trim().trimEnd('.', ',', ' '))
            }
            val t = MSG_TARGET.find(s)
            if (t != null) return Cmd.Message(via, cleanTarget(t.groupValues[1]), null)
            return Cmd.Unknown(raw)
        }

        CALL.find(s)?.let { return Cmd.Call(cleanTarget(it.groupValues[1])) }
        OPEN.find(s)?.let { return Cmd.OpenApp(it.groupValues[1].trim()) }
        if (TIME.containsMatchIn(s)) return Cmd.Time
        if (DATE.containsMatchIn(s)) return Cmd.DateToday
        if (CANCEL.matches(st)) return Cmd.Cancel
        return Cmd.Unknown(raw)
    }
}
