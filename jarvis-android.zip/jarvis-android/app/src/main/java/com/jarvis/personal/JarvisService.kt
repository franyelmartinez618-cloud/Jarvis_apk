package com.jarvis.personal

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.jarvis.personal.STOP"
        const val PREFS = "jarvis_prefs"
        const val PREF_COUNTRY = "country_code"
        private const val TAG = "Jarvis"
        private const val CHANNEL_ID = "jarvis_listening"
        private const val NOTIF_ID = 1
        private const val MODEL_ASSET = "model-en"
        private const val SPEECH_LANG = "es-419"

        @Volatile var running = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val pendingSpeech = ConcurrentHashMap<String, () -> Unit>()

    private var model: Model? = null
    private var wake: WakeWordListener? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startAsForeground("Cargando…")
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar en primer plano", e)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (model == null) loadModel() else startWake()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        wake?.stop()
        wake = null
        releaseWakeLock()
        scope.cancel()
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
        try { model?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            Log.e(TAG, "TextToSpeech no disponible")
            return
        }
        val options = listOf(
            Locale("es", "AR"), Locale("es", "MX"), Locale("es", "US"), Locale("es", "ES")
        )
        for (l in options) {
            if (tts.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) {
                tts.language = l
                break
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishSpeech(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finishSpeech(utteranceId) }
        })
        ttsReady = true
    }

    private fun finishSpeech(id: String?) {
        if (id == null) return
        val cb = pendingSpeech.remove(id) ?: return
        main.post { cb() }
    }

    // ---------------------------------------------------------------- notificación

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis escuchando", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_launcher), "Detener", stop
            ).build())
            .build()
    }

    private fun startAsForeground(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Jarvis:escuchando").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    // ---------------------------------------------------------------- modelo y palabra de activación

    private fun loadModel() {
        scope.launch {
            try {
                val m = withContext(Dispatchers.IO) { prepareModel() }
                model = m
                startWake()
            } catch (e: Exception) {
                Log.e(TAG, "No se pudo cargar el modelo de voz", e)
                updateNotification("Error: falta el modelo de voz (ver README)")
            }
        }
    }

    private fun prepareModel(): Model {
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        val target = File(filesDir, MODEL_ASSET)
        val marker = File(target, ".ok")
        if (!marker.exists()) {
            val inside = assets.list(MODEL_ASSET)
            if (inside.isNullOrEmpty()) {
                throw IllegalStateException("El modelo '$MODEL_ASSET' no está dentro de la app")
            }
            target.deleteRecursively()
            copyAssetDir(MODEL_ASSET, target)
            marker.writeText("ok")
        }
        return Model(target.absolutePath)
    }

    private fun copyAssetDir(assetPath: String, dest: File) {
        val children = assets.list(assetPath)
        if (children.isNullOrEmpty()) {
            // Es un archivo
            dest.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                FileOutputStream(dest).use { out -> input.copyTo(out) }
            }
        } else {
            dest.mkdirs()
            for (child in children) copyAssetDir("$assetPath/$child", File(dest, child))
        }
    }

    private fun startWake() {
        val m = model ?: return
        if (!running) return
        acquireWakeLock()
        updateNotification("Escuchando: di “Jarvis activate”")
        wake?.stop()
        wake = WakeWordListener(m) { onWake() }.also { it.start() }
    }

    private fun onWake() {
        if (busy || !running) return
        busy = true
        scope.launch {
            try {
                conversation()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error en la conversación", e)
                try { speak("Ocurrió un error.") } catch (_: Exception) {}
            } finally {
                busy = false
                delay(400)
                if (running) startWake()
            }
        }
    }

    // ---------------------------------------------------------------- conversación

    private suspend fun conversation() {
        updateNotification("Te escucho…")
        beep()
        speak("Dime.")
        delay(250)
        val heard = listen()
        if (heard == null) {
            speak("No te escuché.")
            return
        }
        Log.d(TAG, "Escuché: $heard")
        handle(Parser.parse(heard))
    }

    private suspend fun handle(cmd: Cmd) {
        when (cmd) {
            is Cmd.Call -> doCall(cmd.target)
            is Cmd.Message -> doMessage(cmd)
            is Cmd.OpenApp -> doOpenApp(cmd.name)
            Cmd.Time -> speak(timeText())
            Cmd.DateToday -> speak(dateText())
            Cmd.Cancel -> speak("Está bien.")
            is Cmd.Unknown -> speak(
                "No entendí. Puedes decirme: llama a alguien, manda un WhatsApp o un SMS, o abre una aplicación."
            )
        }
    }

    // ---------------------------------------------------------------- llamadas

    private suspend fun doCall(target: String) {
        if (!has(Manifest.permission.CALL_PHONE)) {
            speak("Me falta el permiso de llamadas. Ábreme y dalo.")
            return
        }
        val c = resolve(target) ?: return
        if (!confirm("¿Llamo a ${c.name}?")) return
        placeCall(c)
    }

    private suspend fun placeCall(c: Candidate) {
        val telecom = getSystemService(TelecomManager::class.java)
        speak("Llamando a ${c.name}.")
        try {
            telecom.placeCall(Uri.fromParts("tel", c.number, null), Bundle())
        } catch (e: Exception) {
            Log.e(TAG, "placeCall falló", e)
            speak("No pude iniciar la llamada.")
            return
        }

        // Vigilar la llamada para avisar si falla
        val tm = getSystemService(TelephonyManager::class.java)
        val start = SystemClock.elapsedRealtime()
        var sawActive = false
        while (SystemClock.elapsedRealtime() - start < 25_000) {
            delay(500)
            val state = try {
                @Suppress("DEPRECATION") tm.callState
            } catch (e: SecurityException) {
                return
            }
            val elapsed = SystemClock.elapsedRealtime() - start
            if (state != TelephonyManager.CALL_STATE_IDLE) {
                sawActive = true
            } else if (sawActive) {
                speak(
                    "La llamada se cortó enseguida. Puede que no tengas saldo, " +
                        "que el número esté ocupado o apagado. ¿Quieres que lo intente por WhatsApp? " +
                        "Dímelo con: manda un WhatsApp a ${c.name}."
                )
                return
            } else if (elapsed > 5000) {
                speak("No se pudo realizar la llamada. Revisa tu saldo o la señal.")
                return
            }
        }
    }

    // ---------------------------------------------------------------- mensajes

    private suspend fun doMessage(cmd: Cmd.Message) {
        val c = resolve(cmd.target) ?: return

        var body = cmd.body
        if (body.isNullOrBlank()) {
            speak("¿Qué le digo a ${c.name}?")
            body = listen()
            if (body.isNullOrBlank()) {
                speak("No te escuché, cancelo.")
                return
            }
        }

        val via = if (cmd.via == Via.SMS) "SMS" else "WhatsApp"
        if (!confirm("Mensaje por $via a ${c.name}: $body. ¿Lo envío?")) return

        if (cmd.via == Via.SMS) sendSms(c, body) else openWhatsApp(c, body)
    }

    private suspend fun sendSms(c: Candidate, body: String) {
        if (!has(Manifest.permission.SEND_SMS)) {
            speak("Me falta el permiso de SMS.")
            return
        }
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION") SmsManager.getDefault()
            }
            val parts = sms.divideMessage(body)
            sms.sendMultipartTextMessage(c.number, null, parts, null, null)
            speak("Listo, SMS enviado a ${c.name}.")
        } catch (e: Exception) {
            Log.e(TAG, "SMS falló", e)
            speak("No pude enviar el SMS.")
        }
    }

    private suspend fun openWhatsApp(c: Candidate, body: String) {
        if (!Settings.canDrawOverlays(this)) {
            speak("Para abrir WhatsApp desde segundo plano necesito el permiso de mostrar sobre otras apps.")
            return
        }
        val phone = whatsappNumber(c.number)
        val uri = Uri.parse("https://wa.me/$phone?text=" + Uri.encode(body))
        val packages = listOf("com.whatsapp", "com.whatsapp.w4b", null)
        for (pkg in packages) {
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (pkg != null) intent.setPackage(pkg)
            try {
                startActivity(intent)
                speak("Abrí WhatsApp con el mensaje. Toca enviar.")
                return
            } catch (_: Exception) {
                // probar el siguiente
            }
        }
        speak("No pude abrir WhatsApp.")
    }

    /** wa.me necesita el número en formato internacional, sin + ni espacios. */
    private fun whatsappNumber(raw: String): String {
        val hasPlus = raw.trim().startsWith("+")
        var digits = raw.filter { it.isDigit() }
        if (hasPlus) return digits
        if (digits.startsWith("00")) return digits.removePrefix("00")
        val cc = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_COUNTRY, "")?.filter { it.isDigit() } ?: ""
        if (cc.isNotEmpty() && !digits.startsWith(cc)) {
            digits = cc + digits.trimStart('0')
        }
        return digits
    }

    // ---------------------------------------------------------------- abrir apps, hora, fecha

    private suspend fun doOpenApp(name: String) {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = strip(name).trim()
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { strip(it.loadLabel(pm).toString()).contains(q) }
        if (match == null) {
            speak("No encontré una aplicación llamada $name.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            speak("Necesito el permiso de mostrar sobre otras apps para abrirla.")
            return
        }
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        if (intent == null) {
            speak("No pude abrir $name.")
            return
        }
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            speak("Abriendo ${match.loadLabel(pm)}.")
        } catch (e: Exception) {
            Log.e(TAG, "abrir app falló", e)
            speak("No pude abrir $name.")
        }
    }

    private fun timeText(): String {
        val c = Calendar.getInstance()
        val h24 = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val periodo = when (h24) {
            in 0..11 -> "de la mañana"
            in 12..18 -> "de la tarde"
            else -> "de la noche"
        }
        return if (m == 0) "Son las $h12 en punto $periodo."
        else "Son las $h12 y $m $periodo."
    }

    private fun dateText(): String {
        val f = java.text.SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale.forLanguageTag("es"))
        return "Hoy es " + f.format(Calendar.getInstance().time) + "."
    }

    // ---------------------------------------------------------------- resolver contactos

    /** Devuelve a quién llamar/escribir; si hay dudas, pregunta. Null si hay que cancelar. */
    private suspend fun resolve(target: String): Candidate? {
        Contacts.asNumber(target)?.let { num ->
            return Candidate(num.chunked(3).joinToString(" "), "", num)
        }
        if (!has(Manifest.permission.READ_CONTACTS)) {
            speak("Me falta el permiso de contactos.")
            return null
        }
        val found = withContext(Dispatchers.IO) { Contacts.find(this@JarvisService, target) }
        if (found.isEmpty()) {
            speak("No encontré a $target en tus contactos.")
            return null
        }
        if (found.size == 1) return found[0]

        val options = found.take(4)
        val list = options.mapIndexed { i, c -> "${i + 1}, ${c.label}" }.joinToString(". ")
        speak("Encontré varias opciones. $list. ¿Cuál?")
        val answer = listen()
        if (answer == null) {
            speak("No te escuché, cancelo.")
            return null
        }
        val picked = pick(options, strip(answer))
        if (picked == null) {
            speak("No entendí cuál, cancelo.")
        }
        return picked
    }

    private fun pick(options: List<Candidate>, a: String): Candidate? {
        val words = a.split(Regex("\\s+"))
        val ordinals = listOf(
            setOf("1", "uno", "primero", "primera", "primer"),
            setOf("2", "dos", "segundo", "segunda"),
            setOf("3", "tres", "tercero", "tercera"),
            setOf("4", "cuatro", "cuarto", "cuarta")
        )
        for ((i, set) in ordinals.withIndex()) {
            if (i < options.size && words.any { it in set }) return options[i]
        }
        val answer = a.trim()
        if (answer.isEmpty()) return null
        val byLabel = options.filter { opt ->
            val label = strip(opt.label)
            label.contains(answer) || words.all { w -> label.contains(w) }
        }
        return if (byLabel.size == 1) byLabel[0] else null
    }

    private suspend fun confirm(question: String): Boolean {
        speak(question)
        val answer = listen()
        if (answer == null) {
            speak("No te escuché, cancelo.")
            return false
        }
        val words = strip(answer).split(Regex("\\s+"))
        val no = setOf("no", "cancela", "cancelar", "negativo", "nada", "para")
        val yes = setOf("si", "sii", "claro", "dale", "ok", "okay", "afirmativo", "correcto", "seguro", "hazlo", "adelante", "yes", "envialo", "llama")
        return when {
            words.any { it in no } -> { speak("Cancelado."); false }
            words.any { it in yes } -> true
            else -> { speak("No entendí, cancelo."); false }
        }
    }

    // ---------------------------------------------------------------- voz: hablar y escuchar

    private fun has(permission: String) =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private suspend fun speak(text: String) {
        if (!ttsReady) {
            // esperar un poco a que el motor de voz esté listo
            var waited = 0
            while (!ttsReady && waited < 3000) { delay(100); waited += 100 }
            if (!ttsReady) return
        }
        suspendCancellableCoroutine<Unit> { cont ->
            val id = UUID.randomUUID().toString()
            pendingSpeech[id] = { if (cont.isActive) cont.resume(Unit) }
            cont.invokeOnCancellation { pendingSpeech.remove(id) }
            val r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (r == TextToSpeech.ERROR) {
                pendingSpeech.remove(id)
                if (cont.isActive) cont.resume(Unit)
            }
        }
    }

    /** Escucha una frase con el reconocimiento de voz de Android. Null si no se oyó nada. */
    private suspend fun listen(): String? = suspendCancellableCoroutine { cont ->
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "Reconocimiento de voz no disponible")
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        var finished = false
        lateinit var timeout: Runnable

        fun finish(result: String?) {
            if (finished) return
            finished = true
            main.removeCallbacks(timeout)
            try { recognizer.destroy() } catch (_: Exception) {}
            if (cont.isActive) cont.resume(result)
        }
        timeout = Runnable { finish(null) }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                Log.d(TAG, "SpeechRecognizer error $error")
                finish(null)
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                finish(list?.firstOrNull())
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, SPEECH_LANG)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        cont.invokeOnCancellation { main.post { finish(null) } }
        main.postDelayed(timeout, 15_000)
        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening falló", e)
            finish(null)
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 500)
        } catch (_: Exception) {}
    }
}
