package com.jarvis.personal

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Escucha el micrófono sin parar y, de forma 100% offline con Vosk,
 * detecta la frase "jarvis activate". Al detectarla libera el micrófono
 * y avisa con onWake() (en el hilo principal).
 */
class WakeWordListener(
    private val model: Model,
    private val onWake: () -> Unit
) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    companion object {
        private const val TAG = "WakeWord"
        private const val SAMPLE_RATE = 16000
        // Gramática restringida: solo la frase de activación (o "desconocido")
        private const val GRAMMAR = "[\"jarvis activate\", \"[unk]\"]"
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            var triggered = false
            var record: AudioRecord? = null
            var recognizer: Recognizer? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                record = AudioRecord(
                    MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, SAMPLE_RATE)
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "No se pudo abrir el micrófono")
                    return@Thread
                }
                recognizer = Recognizer(model, SAMPLE_RATE.toFloat(), GRAMMAR)
                record.startRecording()
                val buffer = ShortArray(4000)
                while (running) {
                    val n = record.read(buffer, 0, buffer.size)
                    if (n <= 0) {
                        Thread.sleep(50)
                        continue
                    }
                    val text = if (recognizer.acceptWaveForm(buffer, n)) {
                        JSONObject(recognizer.getResult()).optString("text")
                    } else {
                        JSONObject(recognizer.getPartialResult()).optString("partial")
                    }
                    if (text.contains("jarvis") && text.contains("activate")) {
                        triggered = true
                        break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error escuchando", e)
            } finally {
                try { record?.stop() } catch (_: Exception) {}
                try { record?.release() } catch (_: Exception) {}
                try { recognizer?.close() } catch (_: Exception) {}
                running = false
            }
            if (triggered) main.post { onWake() }
        }.also {
            it.name = "wake-word"
            it.start()
        }
    }

    fun stop() {
        running = false
        val t = thread
        if (t != null && t != Thread.currentThread()) {
            try { t.join(2000) } catch (_: InterruptedException) {}
        }
        thread = null
    }
}
