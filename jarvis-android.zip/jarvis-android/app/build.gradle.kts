plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.personal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.personal"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // El Redmi Note 13 es arm64: así el APK pesa menos
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // El modelo de voz son archivos binarios grandes: no comprimirlos
    androidResources {
        noCompress += listOf("mdl", "fst", "conf", "dubm", "ie", "mat", "int", "txt", "uuid")
    }
}

dependencies {
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
